#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<dos.h>
#include<windows.h>

//#include"OpeningAnimation.h"

void gotoxy(int x, int y)           //definition of gotoxy function//                                               
{
 COORD coord = {x,y};
 SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
} 

void welcome()
{
	getch();
	system("color 3f");
	int j=5;
	for(int i=1; i<=193; i++)
	{
		gotoxy(j,3);
		printf("*");
		j++;
	}
	int k=3;
	for(int i=1; i<=30; i++)
	{
		gotoxy(j,k);
		printf("*");
		k++;
	}
	for(int i=j; i>=5; i--)
	{
		gotoxy(j,k);
		printf("*");
		j--;
	}
	for(int i=1; i<=30; i++)
	{
		gotoxy(5,k);
		printf("*");
		k--;
	}
    Sleep(1000);
	//lower
	gotoxy(7,5); printf("    PPPPPPPPPPPPPPPPP       AAAAAAAAAAAAAAAAA     KKKK           KKKK            BBBBBBBBBBBBBBBB          AAAAAAAAAAAAAAAAA     NNNNNNNN                         NNNN   KKKK           KKKK\n");
	Sleep(50);
	gotoxy(7,7); printf("  PPPPPPPPPPPPPPPPPPPPP   AAAAAAAAAAAAAAAAAAAAA   KKKK         KKKK              BBBBBBBBBBBBBBBBBB      AAAAAAAAAAAAAAAAAAAAA   NNNNNNNNNN                       NNNN   KKKK         KKKK\n");
	Sleep(50);
	gotoxy(7,9); printf("  PPPP             PPPP   AAAA             AAAA   KKKK       KKKK                BBBB             BBB    AAAA             AAAA   NNNN    NNNN                     NNNN   KKKK       KKKK\n");
	Sleep(50);
	gotoxy(7,11); printf("  PPPP             PPPP   AAAA             AAAA   KKKK     KKKK                  BBBB             BBBB   AAAA             AAAA   NNNN      NNNN                   NNNN   KKKK     KKKK\n");
	Sleep(50);
	gotoxy(7,13); printf("  PPPP             PPPP   AAAA             AAAA   KKKK   KKKK                    BBBB             BBBB   AAAA             AAAA   NNNN        NNNN                 NNNN   KKKK   KKKK\n");
	Sleep(50);
	gotoxy(7,15); printf("  PPPP             PPPP   AAAA             AAAA   KKKK KKKK                      BBBB             BB     AAAA             AAAA   NNNN          NNNN               NNNN   KKKK KKKK\n");
	Sleep(50);
	gotoxy(7,17); printf("  PPPPPPPPPPPPPPPPPPPP    AAAAAAAAAAAAAAAAAAAAA   KKKKKKKK                       BBBBBBBBBBBBBBBBB       AAAAAAAAAAAAAAAAAAAAA   NNNN            NNNN             NNNN   KKKKKKKK\n");
	Sleep(50);
	gotoxy(7,19); printf("  PPPP                    AAAA             AAAA   KKKK KKKK                      BBBB             BB     AAAA             AAAA   NNNN              NNNN           NNNN   KKKK KKKK\n");
	Sleep(50);
	gotoxy(7,21); printf("  PPPP                    AAAA             AAAA   KKKK   KKKK                    BBBB             BBBB   AAAA             AAAA   NNNN                NNNN         NNNN   KKKK   KKKK\n");
	Sleep(50);
	gotoxy(7,23); printf("  PPPP                    AAAA             AAAA   KKKK     KKKK                  BBBB             BBBB   AAAA             AAAA   NNNN                  NNNN       NNNN   KKKK     KKKK\n");
	Sleep(50);
	gotoxy(7,25); printf("  PPPP                    AAAA             AAAA   KKKK       KKKK                BBBB             BBBB   AAAA             AAAA   NNNN                    NNNN     NNNN   KKKK       KKKK\n");
	Sleep(50);
	gotoxy(7,27); printf("  PPPP                    AAAA             AAAA   KKKK         KKKK              BBBB             BB     AAAA             AAAA   NNNN                      NNNN   NNNN   KKKK         KKKK\n");
	Sleep(50);
    gotoxy(7,29); printf("  PPPP                    AAAA             AAAA   KKKK           KKKK            BBBBBBBBBBBBBBBBB       AAAA             AAAA   NNNN                        NNNNNNNNN   KKKK           KKKK\n");
	Sleep(50);
	gotoxy(7,30); printf("  PPPP                    AAAA             AAAA   KKKK            KKKK           BBBBBBBBBBBBBBBB        AAAA             AAAA   NNNN                         NNNNNNNN   KKKK            KKKK\n");
    Sleep(100);
	//uper
	gotoxy(7,28); printf("  PPPP                    AAAA             AAAA   KKKK          KKKK             BBBBBBBBBBBBBBBBBB      AAAA             AAAA   NNNN                       NNNNNNNNNN   KKKK          KKKK\n");
	Sleep(50);
	gotoxy(7,26); printf("  PPPP                    AAAA             AAAA   KKKK        KKKK               BBBB             BBB    AAAA             AAAA   NNNN                     NNNN    NNNN   KKKK        KKKK\n");
	Sleep(50);
	gotoxy(7,24); printf("  PPPP                    AAAA             AAAA   KKKK      KKKK                 BBBB             BBBB   AAAA             AAAA   NNNN                   NNNN      NNNN   KKKK      KKKK\n");
	Sleep(50);
	gotoxy(7,22); printf("  PPPP                    AAAA             AAAA   KKKK    KKKK                   BBBB             BBBB   AAAA             AAAA   NNNN                 NNNN        NNNN   KKKK    KKKK\n");
	Sleep(50);
	gotoxy(7,20); printf("  PPPP                    AAAA             AAAA   KKKK  KKKK                     BBBB             BBB    AAAA             AAAA   NNNN               NNNN          NNNN   KKKK  KKKK\n");
	Sleep(50);
	gotoxy(7,18); printf("  PPPPPPPPPPPPPPPPPPP     AAAAAAAAAAAAAAAAAAAAA   KKKKKKKK                       BBBBBBBBBBBBBBBBBB      AAAAAAAAAAAAAAAAAAAAA   NNNN             NNNN            NNNN   KKKKKKKK\n");
	Sleep(50);
	gotoxy(7,16); printf("  PPPPPPPPPPPPPPPPPPPPP   AAAAAAAAAAAAAAAAAAAAA   KKKKKKKK                       BBBBBBBBBBBBBBBBBB      AAAAAAAAAAAAAAAAAAAAA   NNNN           NNNN              NNNN   KKKKKKKK\n");
	Sleep(50);
	gotoxy(7,14); printf("  PPPP             PPPP   AAAA             AAAA   KKKK  KKKK                     BBBB             BBB    AAAA             AAAA   NNNN         NNNN                NNNN   KKKK  KKKK\n");
	Sleep(50);
	gotoxy(7,12); printf("  PPPP             PPPP   AAAA             AAAA   KKKK    KKKK                   BBBB             BBBB   AAAA             AAAA   NNNN       NNNN                  NNNN   KKKK    KKKK\n");
	Sleep(50);
	gotoxy(7,10); printf("  PPPP             PPPP   AAAA             AAAA   KKKK      KKKK                 BBBB             BBBB   AAAA             AAAA   NNNN     NNNN                    NNNN   KKKK      KKKK\n");
	Sleep(50);
	gotoxy(7,8); printf("  PPPP             PPPP   AAAA             AAAA   KKKK        KKKK               BBBB             BB     AAAA             AAAA   NNNN   NNNN                      NNNN   KKKK        KKKK\n");
	Sleep(50);
	gotoxy(7,6); printf("   PPPPPPPPPPPPPPPPPPP     AAAAAAAAAAAAAAAAAAA    KKKK          KKKK             BBBBBBBBBBBBBBBBB        AAAAAAAAAAAAAAAAAAA    NNNNNNNNN                        NNNN   KKKK          KKKK\n");
	Sleep(50);
	gotoxy(7,37); printf("Please wait.....");
	int jj=7;
	for(int i=1; i<=191; i++)
	{
		gotoxy(jj,39);
		printf("%c",223);
		if(i==50||i==170)
			Sleep(1000);
		Sleep(5);
		jj++;
	}
	Sleep(50);
	system("cls");
}
int main(){
	welcome();
}

