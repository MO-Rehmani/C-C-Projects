#include<stdio.h>
#include<conio.h>   
#include<windows.h> // for sleep function
#include<dos.h>


void gotoxy(int x, int y)           //definition of gotoxy function//                                               
{
 COORD coord = {x,y};
 SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
} //it is the position of output

void T1(int x, int y) // defination of T alphabate
{
	gotoxy(x,y); printf("TTTTTTTTTTTTTT\n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("      TT\n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("      TT\n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("      TT\n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("      TT\n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("      TT\n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("      TT\n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("      TT\n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("      TT\n");
	//Sleep(35);
}
void E1(int x, int y) //defination of E alphabate
{
	gotoxy(x,y); printf("EE EEEEEEE \n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("EE         \n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("EE         \n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("EE         \n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("EEEEEEE    \n");
	y++;
	//Sleep(35);
	gotoxy(x,y); printf("EE         \n");
	y++;
	
	gotoxy(x,y); printf("EE         \n");
	y++;
	gotoxy(x,y); printf("EE         \n");
	y++;
	gotoxy(x,y); printf("EEEEEEEEEE \n");
}
void H1(int x, int y) //defination of H alphabate
{
	Sleep(40);
	gotoxy(x,y); printf("HH       HH\n");
	y--;
	Sleep(40);
	gotoxy(x,y); printf("HH       HH\n");
	y--;
	Sleep(40);
	gotoxy(x,y); printf("HH       HH\n");
	y--;
	Sleep(40);
	gotoxy(x,y); printf("HH       HH\n");
	y--;
	Sleep(40);
	gotoxy(x,y); printf("HHHHHHHHHHH\n");
	y--;
	Sleep(40);
	gotoxy(x,y); printf("HH       HH\n");
	y--;
	Sleep(40);
	gotoxy(x,y); printf("HH       HH\n");
	y--;
	Sleep(40);
	gotoxy(x,y); printf("HH       HH\n");
	y--;
	Sleep(40);
	gotoxy(x,y); printf("HH       HH\n");
	Sleep(40);
}

int animation()
{
	getch(); // for hold screen
	system("cls"); // for clear screen
	system("color 3f");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //top left
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");
	
	gotoxy(1,39);   printf(";;;;;;;;       ;;;;;;\n");   // bottum left
	gotoxy(1,42);   printf(";;;;;;;;;;;;;;;;;;;;;\n");
	gotoxy(1,45);   printf(";;;;;;;;       ;;;;;;\n");
	gotoxy(1,48);   printf(";;;;;;;;       ;;;;;;\n");
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n");     
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n"); //center
	
	gotoxy(185,1); printf(";;;;;;;;       ;;;;;;\n");
	gotoxy(185,3); printf(";;;;;;;;      ;;;;;;;\n");   //top right
	gotoxy(185,6); printf(";;;;;;;;     ;;;;;;;;\n");
	gotoxy(185,9); printf(";;;;;;;;    ;;;;;;;;;\n");
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");
	Sleep(100);
	
	system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //top left
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");
	
	gotoxy(1,39);   printf(";;;;;;;;       ;;;;;;\n");   // bottum left
	gotoxy(1,42);   printf(";;;;;;;;;;;;;;;;;;;;;\n");
	gotoxy(1,45);   printf(";;;;;;;;       ;;;;;;\n");
	gotoxy(1,48);   printf(";;;;;;;;       ;;;;;;\n");
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n");     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //center
	
	gotoxy(185,1); printf(";;;;;;;;       ;;;;;;\n");
	gotoxy(185,3); printf(";;;;;;;;      ;;;;;;;\n");   //top right
	gotoxy(185,6); printf(";;;;;;;;     ;;;;;;;;\n");
	gotoxy(185,9); printf(";;;;;;;;    ;;;;;;;;;\n");
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");
	Sleep(100);
	
	system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(1,42);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(1,45);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(1,48);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(185,1); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(185,3); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(185,6); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(185,9); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
	system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(1,42);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(1,45);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(1,48);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(185,3); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(185,6); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(185,9); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
	system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(1,45);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(1,48);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(185,3); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(185,6); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(185,9); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
		system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(1,45);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(1,48);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(185,6); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(185,9); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);

		system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(1,48);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(185,6); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(185,9); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);

		system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(1,48);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(185,9); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);

		system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(185,9); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);

		system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(85,28); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(185,48); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
		system("cls");
	gotoxy(1,1);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(85,28); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(85,32); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
		system("cls");
	gotoxy(85,15);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(85,28); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(185,45); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(85,32); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
	
		system("cls");
	gotoxy(85,15);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(1,3);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(85,28); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(85,31); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(85,32); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
			system("cls");
	gotoxy(85,15);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(85,16);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(85,28); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(185,42); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(85,31); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(85,32); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
	
			system("cls");
	gotoxy(85,15);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(85,16);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(1,6);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(85,28); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(85,30); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(85,31); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(85,32); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
	system("cls");
	gotoxy(85,15);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(85,16);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(85,17);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(85,28); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(185,39); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(85,30); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(85,31); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(85,32); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
	system("cls");
	gotoxy(85,15);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(85,16);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(85,17);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(1,9);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(85,28); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(85,29); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(85,30); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(85,31); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(85,32); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	
		system("cls");
	gotoxy(85,15);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	gotoxy(85,16);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	gotoxy(85,17);   printf(";;;;;;;;       ;;;;;;\n");   //17
	gotoxy(85,18);   printf(";;;;;;;;       ;;;;;;\n");   //18
	
	gotoxy(85,19);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	gotoxy(85,20);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	gotoxy(85,21);   printf(";;;;;;;;       ;;;;;;\n");  //21
	gotoxy(85,22);   printf(";;;;;;;;       ;;;;;;\n");  //22
	
	gotoxy(85,23); printf(";;;;;;;;       ;;;;;;\n"); //23     
	gotoxy(85,24); printf(";;;;;;;;       ;;;;;;\n"); //24    center
	
	gotoxy(85,25); printf(";;;;;;;;       ;;;;;;\n");  //25
	gotoxy(85,26); printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	gotoxy(85,27); printf(";;;;;;;;     ;;;;;;;;\n");   //27
	gotoxy(85,28); printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	
	gotoxy(85,29); printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	gotoxy(85,30); printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	gotoxy(85,31); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	gotoxy(85,32); printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(100);
	int semi;
	
	semi=16;
	//system("cls");
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //17
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //18
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //21
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //22
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //25
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	
	
	semi=17;
	//system("cls");
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //17
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //18
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //21
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //22
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //25
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	
	
	semi=18;
	//system("cls");
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //17
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //18
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //21
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //22
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //25
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	
	
	semi=19;
	//system("cls");
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //17
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //18
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //21
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //22
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //25
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	
	
	semi=20;
	//system("cls");
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //17
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //18
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //21
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //22
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //25
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	
	
	semi=21;
	//system("cls");
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //17
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //18
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //21
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //22
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //25
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	
	semi=22;
	//system("cls");
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //17
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //18
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //21
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //22
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;       ;;;;;;\n");  //25
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	semi++;
	gotoxy(85,semi);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	



	int colo=22;
	int colon=22;
	semi=86;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	//semi++;
	colo=22;
	semi=87;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	colo=22;
	semi=88;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	colo=22;

	semi=89;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	colo++;
	//semi++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	colo++;
	//semi++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
colo=22;
	semi=90;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
colo=22;
	semi=91;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);
	colo=22;

	semi=92;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=22;

	semi=93;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=22;

	semi=94;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=22;

	semi=95;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=22;

	semi=96;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=22;

	semi=97;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=22;

	semi=98;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=22;

	semi=99;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

	colo=21;

	semi=99;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=20;

	semi=99;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=19;

	semi=99;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=18;

	semi=99;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=17;

	semi=99;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=16;

	semi=99;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(30);

colo=15;

	semi=99;
	//system("cls");
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //15     top left            
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //16
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //17
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //18
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");   //19    bottum left
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");  //20
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //21
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //22
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //23     
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n"); //24    center
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;       ;;;;;;\n");  //25
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;      ;;;;;;;\n");   //26    top right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;     ;;;;;;;;\n");   //27
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;    ;;;;;;;;;\n");    //28
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;   ;;;;;;;;;;\n"); //29    bottum right
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;  ;;;;;;;;;;;\n");  //30
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //31
	//semi++;
	colo++;
	gotoxy(semi,colo);   printf(";;;;;;;;;;;;;;;;;;;;;\n");   //32
	Sleep(500);
	int j=50;
	
	gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
	
	gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
    gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
gotoxy(2,j);printf(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
	Sleep(10);
	j--;
	Sleep(500);
	system("cls");
	system("color 3f");
	Sleep(100);
	T1(10,5); //call T with 10 x-axis and 5 y-axis
	Sleep(200);
	H1(26,13);
	Sleep(200);
	E1(40,5);
	Sleep(100);
	
	char s1 []="  SSSSSSSSSSSSSSSS    EE EEEEEEEEEEEEEE    MMMMMMMMMMMM   MMMMMMMMMMMM    IIIIIIIIIIIII    CCCCCCCCCCCCCCC    OOOOOOOOOOOOOOOO   LLL                 OOOOOOOOOOOOOOOO   NNNNNN       NNN  ;;;;;;;;;;;;;;;;;;;;;";
	char s2 []=" SSSSSSSSSSSSSSSSSS  EEE EEEEEEEEEEEEEEE  MMMMMMMMMMMMMM MMMMMMMMMMMMMM  IIIIIIIIIIIIIII  CCCCCCCCCCCCCCCCC  OOOOOOOOOOOOOOOOOO  LLL                OOOOOOOOOOOOOOOOOO  NNN NNN      NNN  ;;;;;;;;;;       ;;;;";
	char s3 []="SSSSSSSSSSSSSSSSSS   EEE EEEEEEEEEEEEEE   MMMMMMMMMMMMMMMMMMMMMMMMMMMMM        III        CCCCCCCCCCCCCCCC   OOOOOOOOOOOOOOOOOO  LLL                OOOOOOOOOOOOOOOOOO  NNN  NNN     NNN  ;;;;;;;;;;       ;;;;";
	char s4 []="SSS                  EEE                  MMM        MMMMMMM        MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN   NNN    NNN  ;;;;;;;;;;       ;;;;";
	char s5 []="SSS                  EEE                  MMM         MMMMM         MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN    NNN   NNN  ;;;;;;;;;;;;;;;;;;;;;";
	char s6 []="SSS                  EEE                  MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN     NNN  NNN  ;;;;;;;;;;       ;;;;";
	char s7 []="SSS                  EEE                  MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN     NNN  NNN  ;;;;;;;;;;       ;;;;";
	char s8 []="SSS                  EEE                  MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN     NNN  NNN  ;;;;;;;;;;       ;;;;";
	char s9 []="SSSSSSSSSSSSSSSSSS   EEEEEEEEEEEEEEE      MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN     NNN  NNN  ;;;;;;;;;;       ;;;;";
	char s10[]="SSSSSSSSSSSSSSSSSSS  EEEEEEEEEEEEEEE      MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN     NNN  NNN  ;;;;;;;;;;       ;;;;";
	char s11[]=" SSSSSSSSSSSSSSSSSS  EEEEEEEEEEEEEEE      MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN     NNN  NNN  ;;;;;;;;;;      ;;;;;";
	char s12[]="                SSS  EEE                  MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN     NNN  NNN  ;;;;;;;;;;     ;;;;;;";
	char s13[]="                SSS  EEE                  MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN     NNN  NNN  ;;      ;;    ;;;;;;;";
	char s14[]="                SSS  EEE                  MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN     NNN  NNN  ;;;;;;  ;;   ;;;;;;;;";
	char s15[]="                SSS  EEE                  MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN    NNN   NNN  ;;;;;  ;;;;;;;;;;;;;;";
	char s16[]="                SSS  EEE                  MMM          MMM          MMM        III        CCC                OOO            OOO  LLL                OOO            OOO  NNN   NNN    NNN  ;;;;  ;;;;;;;;;;;;;;;";
	char s17[]=" SSSSSSSSSSSSSSSSSS  EEEEEEEEEEEEEEEEEE   MMM          MMM          MMM        III        CCCCCCCCCCCCCCCC   OOOOOOOOOOOOOOOOOO  LLL                OOOOOOOOOOOOOOOOOO  NNN   NNN    NNN  ;;;  ;;;;;;;;;;;;;;;;";
	char s18[]="SSSSSSSSSSSSSSSSSSS  EEEEEEEEEEEEEEEEEEE  MMM          MMM          MMM  IIIIIIIIIIIIIII  CCCCCCCCCCCCCCCCC  OOOOOOOOOOOOOOOOOO  LLLLLLLLLLLLLLLLL  OOOOOOOOOOOOOOOOOO  NNN   NNNNNNNNNN  ;;      ;;;;;;;;;;;;;";
	char s19[]=" SSSSSSSSSSSSSSSSS    EEEEEEEEEEEEEEEEE   MMM          MMM          MMM   IIIIIIIIIIIII    CCCCCCCCCCCCCCC    OOOOOOOOOOOOOOOO   LLLLLLLLLLLLLLLLL   OOOOOOOOOOOOOOOO   NNN   NNNNNNNNNN  ;;;;;;;;;;;;;;;;;;;;;";
	
	
	
	
	int n=1;
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,18);
		printf("%c",s1[i]);
		Sleep(n);
	}
	printf("\n");
	
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,19);
		printf("%c",s2[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,20);
		printf("%c",s3[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,21);
		printf("%c",s4[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,22);
		printf("%c",s5[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,23);
		printf("%c",s6[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,24);
		printf("%c",s7[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,25);
		printf("%c",s8[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,26);
		printf("%c",s9[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,27);
		printf("%c",s10[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,28);
		printf("%c",s11[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,29);
		printf("%c",s12[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,30);
		printf("%c",s13[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,31);
		printf("%c",s14[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,32);
		printf("%c",s15[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,33);
		printf("%c",s16[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,34);
		printf("%c",s17[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,35);
		printf("%c",s18[i]);
		//Sleep(n);
	}
	printf("\n");
	Sleep(1);
	for (int i=0; i<=strlen(s1); i++)
	{
		gotoxy(i+1,36);
		printf("%c",s19[i]);
		Sleep(n);
	}
	Sleep(1000);
	system("cls");
	//printf("\n");
}

int main(){
	animation();
}

